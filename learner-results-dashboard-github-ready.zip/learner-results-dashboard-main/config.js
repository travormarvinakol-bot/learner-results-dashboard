/* Supabase browser configuration. Use ONLY the publishable/anon public key.
   Never put a service_role or secret key in this file. */
window.SUPABASE_URL = "https://myfafxoozmdajxlmvffn.supabase.co";
window.SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE";
