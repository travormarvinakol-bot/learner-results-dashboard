# Learner Results Dashboard

## Files
- `index.html` — main page
- `style.css` — styling
- `config.js` — Supabase browser configuration
- `app.js` — login, results, grading, sharing and comments

## Supabase setup
1. Open `config.js`.
2. Keep the project URL already entered.
3. Replace `PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE` with your Supabase **publishable** key (or legacy anon public key).
4. Never use a `service_role` or secret key in a browser file.

## Grading
- A: 80–100 = 3.0 points
- B: 70–79 = 2.5 points
- C: 60–69 = 2.0 points
- D: 50–59 = 1.5 points
- E: 0–49 = 0.9 points
- X: examination not done = 0.0 points; included as zero in averages

`X` is stored as `-1` in the existing numeric `marks.mark` column. Ensure that column has no database CHECK constraint requiring values to be at least 0. Blank entries remain NULL and are not included in averages.

## Publish
Commit `index.html`, `style.css`, `config.js`, `app.js`, and this README to the repository's `main` branch. GitHub Pages should serve `index.html`.
